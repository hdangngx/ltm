@javax.xml.bind.annotation.XmlSchema(namespace = "http://medianews.vn/")
package vn.medianews;
