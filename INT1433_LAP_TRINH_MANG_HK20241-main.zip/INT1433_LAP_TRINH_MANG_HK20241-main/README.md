1. Tất cả ngoại lệ các bạn chỉ cần throws Exception thôi, không cần nhiều ngoại lệ làm gì
2. Môn này cũng thi AC, nhưng không so sánh văn bản in ra màn hình. Máy chỉ chấm cái các bạn gửi lên máy chủ thôi. Các bạn muốn in cái gì ra màn hình thì tuỳ nhé, code của mình có nhiều chỗ in chỉ để soi quá trình làm cho dễ thôi, bỏ chỗ đó cũng không sao. 
3. Mọi ý kiến, đóng góp về đề thi và đáp án, các bạn vui lòng liên hệ trực tiếp với mình tại https://www.facebook.com/nguyen.hoang.hai.534997/
4. Git này là năm đầu tiên mình tổng hợp đề thi, thời điểm ấy vừa tổng hợp đề vừa làm cho nên chưa có thời gian sắp xếp đề thi và đáp án sao cho khoa học. Các bạn có thời gian thì tải toàn bộ đề, đáp án và tự sắp xếp lại theo cách mình muốn, sao cho thuận lợi nhất khi ôn thi nhé.
